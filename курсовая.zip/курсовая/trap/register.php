<?php include "db.php";

if ($_POST) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn, "INSERT INTO users (username,email,password)
    VALUES ('$username','$email','$password')");

    header("Location: login.php");
}
?>

<form method="post">
    <input name="username" placeholder="Логин" required>
    <input name="email" placeholder="Email" required>
    <input type="password" name="password" placeholder="Пароль" required>
    <button>Регистрация</button>
</form>
