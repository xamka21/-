<?php include "db.php";
if ($_SESSION['role'] !== 'admin') die("Нет доступа");

if ($_POST) {
    $title = $_POST['title'];
    $desc = $_POST['description'];

    mysqli_query($conn, "INSERT INTO recipes (title,description)
    VALUES ('$title','$desc')");
}
?>

<form method="post">
    <input name="title" placeholder="Название">
    <textarea name="description" placeholder="Описание"></textarea>
    <button>Добавить</button>
</form>
