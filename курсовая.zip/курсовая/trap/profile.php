<?php include "db.php";
if (!isset($_SESSION['user_id'])) header("Location: login.php");

$id = $_SESSION['user_id'];

if ($_POST) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    mysqli_query($conn, "UPDATE users SET username='$username', email='$email' WHERE id=$id");
}

$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id=$id"));
?>

<h2>Профиль</h2>

<form method="post">
    <input name="username" value="<?= $user['username'] ?>">
    <input name="email" value="<?= $user['email'] ?>">
    <button>Сохранить</button>
</form>

<?php if ($_SESSION['role'] == 'admin'): ?>
    <a href="add_recipe.php">Добавить рецепт</a>
<?php endif; ?>
