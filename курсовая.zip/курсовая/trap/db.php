<?php
$conn = mysqli_connect("localhost", "root", "root", "trapitb");
session_start();

if (!$conn) {
    die("Ошибка подключения");
}
?>
