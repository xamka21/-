<?php include "db.php";

if ($_POST) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
    $user = mysqli_fetch_assoc($res);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        header("Location: index.php");
    } else {
        echo "Ошибка входа";
    }
}
?>

<form method="post">
    <input name="username" placeholder="Логин">
    <input type="password" name="password" placeholder="Пароль">
    <button>Войти</button>
</form>
