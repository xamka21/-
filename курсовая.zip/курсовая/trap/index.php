<?php include "db.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Рецепты</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>🍲 Рецепты</h1>

<?php if (!isset($_SESSION['user_id'])): ?>
    <a href="login.php">Вход</a> |
    <a href="register.php">Регистрация</a>
<?php else: ?>
    <a href="profile.php">Профиль</a> |
    <a href="logout.php">Выход</a>
<?php endif; ?>

<hr>

<?php
$result = mysqli_query($conn, "SELECT * FROM recipes");
while ($row = mysqli_fetch_assoc($result)):
?>
<div class="card">
    <h3><?= $row['title'] ?></h3>
    <p><?= $row['description'] ?></p>
</div>
<?php endwhile; ?>

</body>
</html>
